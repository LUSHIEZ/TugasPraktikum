package com.example.tugaspam

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
